function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6FQ2iXMpDeh":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

